package peng.tdd.ct;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午5:21
 * To change this template use File | Settings | File Templates.
 */
public class ProposedTalk {
    private final String name;
    private final int length;

    public ProposedTalk(String description) {
        this.name = description.substring(0, description.lastIndexOf(" "));
        String lengthStr = description.substring(description.lastIndexOf(" ")+1, description.length());
        if (lengthStr.equals("lightning")) {
            this.length = 5;
        } else {
            lengthStr = lengthStr.replace("min", "");
            this.length = Integer.parseInt(lengthStr);
        }
    }

    public String getName() {
        return name;
    }

    public int getLength() {
        return this.length;
    }
}
