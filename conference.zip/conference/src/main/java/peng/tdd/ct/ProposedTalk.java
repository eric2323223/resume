package peng.tdd.ct;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午5:21
 * To change this template use File | Settings | File Templates.
 */
public class ProposedTalk {
    private final String name;
    private final int length;

    public ProposedTalk(String description) {
        String[] parts = description.split(" ");
        this.name = parts[0];
        String lengthStr = parts[1].replace("min", "");
        this.length = Integer.parseInt(lengthStr);
    }

    public String getName() {
        return name;
    }

    public int getLength() {
        return this.length;
    }
}
