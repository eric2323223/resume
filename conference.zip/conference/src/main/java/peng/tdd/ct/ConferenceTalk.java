package peng.tdd.ct;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午5:21
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTalk {
    private String startTime;
    private String endTime;
    private String name;
    private String length;

    public ConferenceTalk(String name, String start, String end) {
        this.name = name;
        this.startTime = start;
        this.endTime = end;
    }

    public ConferenceTalk(String s) {
        String[] parts = s.split(" ");
        this.name = parts[0];
        this.length = parts[1];
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getName() {
        return name;
    }

    public boolean isPlaned() {
        if (this.startTime == null && this.endTime == null) {
            return false;
        }
        return true;
    }

    public String getLength() {
        return this.length;
    }
}
