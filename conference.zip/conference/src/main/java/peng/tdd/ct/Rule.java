package peng.tdd.ct;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午6:12
 * To change this template use File | Settings | File Templates.
 */
public class Rule {
    String startNoEarlyThan;

    public Rule() {

    }

    public Rule startNoEarlyThan(String startTime) {
        this.startNoEarlyThan = startTime;
        return this;
    }

    public String getStartNoEarlyThan() {
        return this.startNoEarlyThan;
    }
}
