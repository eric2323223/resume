package peng.tdd.ct;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:18
 * To change this template use File | Settings | File Templates.
 */
public class Timeslot {
    public static String getEndTime(String startTime, String length) {
        int intLength = Integer.parseInt(length);
        int startHour = Integer.parseInt(startTime.substring(0, 2));
        int startMinute = Integer.parseInt(startTime.substring(2, 4));
//        int endHour = startHour + intLength/60;
//        if (startMinute + intLength % 60 > 60) {
//            endHour = endHour +1;
//        }
        int endMinute = startMinute + intLength;
        int endHour = endMinute / 60 + startHour;
        endMinute = endMinute >= 60? endMinute % 60 : endMinute;
        return Integer.toString(endHour) + Integer.toString(endMinute);
    }
}
