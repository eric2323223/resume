package peng.tdd.ct;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:18
 * To change this template use File | Settings | File Templates.
 */
public class Timeslot {
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private int length;
    private String talk = null;

    public String getTalkName() {
        return this.talk;
    }

    public Timeslot(int startHour, int startMinute, int length, String name) {
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = startHour + (this.startMinute +length)/60;
        this.endMinute = (startMinute + length) %60;
        this.length = length;
        this.talk = name;
    }

    public Timeslot substract(Timeslot timeslot) {
        if (this.getLength() == timeslot.getLength()) {
            return null;
        }else if (this.startHour == timeslot.getStartHour() && this.startMinute == timeslot.getStartMinute()){
            int startHour = (this.getStartMinute() + timeslot.getLength())/60 + this.getStartHour();
            int startMinute = (this.getStartMinute() + timeslot.getLength()) % 60;
            return  new Timeslot(startHour, startMinute, this.getEndHour(), this.getEndMinute());
        }else if (this.endHour == timeslot.getEndHour() && this.endMinute == timeslot.getEndMinute()){
            int endHour = this.endHour - timeslot.getLength()/60;
            int endMinute = this.endMinute - timeslot.getLength()%60 ;
            return new Timeslot(startHour, startMinute, endHour, endMinute);
        } else {
            throw new RuntimeException("Such timeslot substraction is not supported.");
        }
    }


    public Timeslot(int startHour, int startMinute, int endHour, int endMinute, String name) {
        initAttributes(startHour, startMinute, endHour, endMinute);
        this.talk = name;
    }

    public Timeslot(int startHour, int startMinute, int endHour, int endMinute) {
        initAttributes(startHour, startMinute, endHour, endMinute);
    }

    private void initAttributes(int startHour, int startMinute, int endHour, int endMinute) {
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.length = (this.endHour - this.startHour) * 60 + (this.endMinute - this.startMinute);
    }

    public int getLength() {
        return this.length;
    }

    public String toString() {
        boolean am = this.startHour<12;
        int startHour = am? this.startHour : this.startHour-12;
        String startHourStr = startHour >= 10 ? Integer.toString(startHour) : "0" + Integer.toString(startHour);
        String startMinStr = startMinute >= 10 ? Integer.toString(startMinute) : "0" + Integer.toString(startMinute);
        String startTimeStr = am? startHourStr+":"+startMinStr+"AM" : startHourStr+":"+startMinStr+"PM";
        String lengthStr = this.length == 5 ? "lightning" : length + "min";
        return startTimeStr + " " + talk + " " + lengthStr;
    }

    private List<ProposedTalk> reorderTalk(List<ProposedTalk> talks) {
        Collections.sort(talks, new Comparator<ProposedTalk>() {
            public int compare(ProposedTalk talk1, ProposedTalk talk2) {
                if (talk1.getLength() > talk2.getLength()) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });
        return talks;
    }

    public int getStartHour() {
        return startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }
}
