package peng.tdd.ct;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:18
 * To change this template use File | Settings | File Templates.
 */
public class Timeslot {
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private int length;
    String talk = null;

    public String getTalkName() {
        return this.talk;
    }

    public Timeslot(int startHour, int startMinute, int length, String name) {
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = startHour + (this.startMinute +length)/60;
        this.endMinute = (startMinute + length) %60;
        this.length = length;
        this.talk = name;
    }

//    public Timeslot(String start, String end) {
//        startHour = Integer.parseInt(start.substring(0, 2));
//        startMinute = Integer.parseInt(start.substring(2, 4));
//        endHour = Integer.parseInt(end.substring(0, 2));
//        endMinute = Integer.parseInt(end.substring(2, 4));
//        this.length = (this.endHour - this.startHour) * 60 + (this.endMinute - this.startMinute);
//    }

    public Timeslot substract(Timeslot timeslot) {
        if (this.getLength() == timeslot.getLength()) {
            return null;
        }else{
            int startHour = (this.getStartMinute() + timeslot.getLength())/60 + this.getStartHour();
            int startMinute = (this.getStartMinute() + timeslot.getLength()) % 60;
            return  new Timeslot(startHour, startMinute, this.getEndHour(), this.getEndMinute());
        }
    }


    public Timeslot(int startHour, int startMinute, int endHour, int endMinute, String name) {
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.length = (this.endHour - this.startHour) * 60 + (this.endMinute - this.startMinute);
        this.talk = name;
    }

    public Timeslot(int startHour, int startMinute, int endHour, int endMinute) {
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.length = (this.endHour - this.startHour) * 60 + (this.endMinute - this.startMinute);
    }

    public int getLength() {
        return this.length;
    }

    public String toString() {
        boolean am = this.startHour<12;
        int startHour = am? this.startHour : this.startHour -12;
        String startHourStr = startHour >= 10 ? Integer.toString(startHour) : "0" + Integer.toString(startHour);
        String startMinStr = startMinute >= 10 ? Integer.toString(startMinute) : "0" + Integer.toString(startMinute);
        String startTimeStr = am? startHourStr+":"+startMinStr+"AM" : startHourStr+":"+startMinStr+"PM";
        return startTimeStr + " " + talk + " " + length + "min";
    }

    public List fit(List<ProposedTalk> talks) {
        int totalLength = 0;
        List<ProposedTalk> orderedTalks = reorderTalk(talks);
        for (ProposedTalk slot : talks) {
            
        }
        return new ArrayList();
    }

    private List<ProposedTalk> reorderTalk(List<ProposedTalk> talks) {
        Collections.sort(talks, new Comparator<ProposedTalk>() {
            public int compare(ProposedTalk talk1, ProposedTalk talk2) {
                if (talk1.getLength() > talk2.getLength()) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });
        return talks;
    }


//    public static String getEndTime(String startTime, String length) {
//        int intLength = Integer.parseInt(length);
//        int startHour = Integer.parseInt(startTime.substring(0, 2));
//        int startMinute = Integer.parseInt(startTime.substring(2, 4));
//        int endMinute = startMinute + intLength;
//        int endHour = endMinute / 60 + startHour;
//        endMinute = endMinute >= 60? endMinute % 60 : endMinute;
//        String endMinuteStr = Integer.toString(endMinute);
//        String endHourStr = Integer.toString(endHour);
//        endMinuteStr = endMinuteStr.length()<2? ("0"+endMinuteStr):endMinuteStr;
//        endHourStr = endHourStr.length()<2? ("0"+endHourStr):endHourStr;
//        return endHourStr + endMinuteStr;
//    }

    public int getStartHour() {
        return startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }
}
