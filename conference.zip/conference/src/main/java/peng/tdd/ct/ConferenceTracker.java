package peng.tdd.ct;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午4:57
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTracker {

    public ConferenceTracker() {

    }

    public List<ConferenceTalk> makePlan(List<String> talks, Rule rule) {
        List<ConferenceTalk> conferenceTalks = new ArrayList<ConferenceTalk>();
        String start = rule.getStartNoEarlyThan();
        ConferenceTalk talk = new ConferenceTalk((String)talks.get(0)) ;
        String end = Timeslot.getEndTime(start, talk.getLength());
        conferenceTalks.add(talk);
        return conferenceTalks;
    }
}
