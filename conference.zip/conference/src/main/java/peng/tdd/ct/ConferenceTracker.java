package peng.tdd.ct;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午4:57
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTracker {
    private List<Timeslot> availableTimeSlots = new ArrayList<Timeslot>();
    private List<Timeslot> planedTimeslots = new ArrayList<Timeslot>();
    private List<ProposedTalk> proposedTalks = null;
    private Timeslot networkEventSlot = null;

    public void setNetworkEventSlot(Timeslot slot) {
        this.networkEventSlot = slot;
        this.planedTimeslots.add(slot);
        Timeslot afternoon = this.availableTimeSlots.get(1);
        this.availableTimeSlots.remove(afternoon);
        Timeslot availableTimeslots = afternoon.substract(slot);
        this.availableTimeSlots.add(1, availableTimeslots);
    }

    public void setAvailableTimeSlots(List<Timeslot> slots) {
        this.availableTimeSlots = slots;
    }

    public List<Timeslot> makePlan(List<ProposedTalk> talks) {
        this.proposedTalks = talks;
        while (this.proposedTalks.size() > 0) {
            if (availableTimeSlots.size() == 0) {
                return null;
            }
            ProposedTalk talk = findMostFitTalk(talks);
            if (talk != null) {
                planSingleTalk(talk);
            } else{
                planSingleTalk(talks.get(0));
            }
        }
        orderTimeslots();
        return this.planedTimeslots;
    }

    private ProposedTalk findMostFitTalk(List<ProposedTalk> talks) {
        for (ProposedTalk talk : talks) {
            for (Timeslot slot : availableTimeSlots) {
                if (talk.getLength() == slot.getLength()) {
                    return talk;
                }
            }
        }
        return null;
    }

    public List<Timeslot> getPlanedTimeslots() {
        return this.planedTimeslots;
    }

    private void orderTimeslots() {
        Collections.sort(this.planedTimeslots, new Comparator<Timeslot>() {
            public int compare(Timeslot o1, Timeslot o2) {
                if (o1.getStartHour() > o2.getStartHour()) {
                    return 1;
                } else if (o1.getStartHour() < o2.getStartHour()) {
                    return -1;
                } else if (o1.getStartMinute() > o2.getStartMinute()) {
                    return 1;
                } else {
                    return -1;
                }

            }
        });
    }

    protected void planSingleTalk(ProposedTalk talk) {
        int insertPos = 0;
        Timeslot talkSlot = null;
        Timeslot leftOffSlot = null;
        for (int i = 0; i < this.availableTimeSlots.size(); i++) {
            Timeslot current = this.availableTimeSlots.get(i);
            if (current.getTalkName() == null && current.getLength() >= talk.getLength()) {
                insertPos = i;
                availableTimeSlots.remove(current);
                talkSlot = new Timeslot(current.getStartHour(), current.getStartMinute(), talk.getLength(), talk.getName());
                leftOffSlot = current.substract(talkSlot);
                break;
            }
        }
        if (talkSlot != null) {
            this.planedTimeslots.add(talkSlot);
            this.proposedTalks.remove(talk);
            if (leftOffSlot != null) {
                this.availableTimeSlots.add(insertPos, leftOffSlot);
            }
        }
    }

    public void printPlan(Writer writer) throws IOException {
        StringBuffer output = new StringBuffer();
        if (this.planedTimeslots.size() > 0) {
            orderTimeslots();
        }
        for (Timeslot timeslot : this.planedTimeslots) {
            output.append(timeslot.toString() + "\n");
        }
        writer.write(output.toString());
        writer.close();
    }
}
