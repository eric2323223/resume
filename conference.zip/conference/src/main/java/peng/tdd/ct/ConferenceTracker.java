package peng.tdd.ct;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午4:57
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTracker {
    List<Timeslot> timeSlots = new ArrayList<Timeslot>();
    List<Timeslot> planedTimeslots = new ArrayList<Timeslot>();

    public ConferenceTracker() {
        this.timeSlots.add(new Timeslot(9,0,12,0));
        this.timeSlots.add(new Timeslot(13,0,18,0));
    }

    public List<Timeslot> makePlan(List<ProposedTalk> talks) {
        for (ProposedTalk talk : talks) {
            planSingleTalk(talk);
        }
        orderTimeslots();
        return this.planedTimeslots;
    }

    public List<Timeslot> getPlanedTimeslots() {
        return this.planedTimeslots;
    }

    private void orderTimeslots() {
        //TODO
    }



    protected void planSingleTalk(ProposedTalk talk) {
        int insertPos = 0;
        Timeslot talkSlot = null;
        Timeslot leftOffSlot = null;
        for(int i =0;i<this.timeSlots.size();i++) {
            Timeslot current = this.timeSlots.get(i);
            if (current.getTalkName()== null && current.getLength() >= talk.getLength()) {
                insertPos = i;
                timeSlots.remove(current);
                talkSlot = new Timeslot(current.getStartHour(), current.getStartMinute(), talk.getLength(), talk.getName());
//                timeSlots.add(talkslot);
                leftOffSlot = current.substract(talkSlot);
                break;
            }
        }
        if(talkSlot!= null) {
            this.planedTimeslots.add(talkSlot);
            if (leftOffSlot != null) {
                this.timeSlots.add(insertPos, leftOffSlot);
            }
        }
    }

    public void printPlan(OutputStream outputStream) {

    }
}
