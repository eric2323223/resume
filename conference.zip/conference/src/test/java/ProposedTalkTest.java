import org.junit.Test;
import peng.tdd.ct.ProposedTalk;

import static org.junit.Assert.assertEquals;

/**
 * Created by 43971153 on 2017/8/22.
 */
public class ProposedTalkTest {

    @Test
    public void testLightningTalk() {
        ProposedTalk talk = new ProposedTalk("sample talk lightning");
        assertEquals("sample talk", talk.getName());
        assertEquals(5, talk.getLength());

    }

    @Test
    public void testOtherTalk() {
        ProposedTalk talk = new ProposedTalk("sample talk1 15min");
        assertEquals("sample talk1", talk.getName());
        assertEquals(15, talk.getLength());

    }

}
