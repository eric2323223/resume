import org.junit.Before;
import peng.tdd.ct.Rule;
import org.junit.Test;
import peng.tdd.ct.ConferenceTalk;
import peng.tdd.ct.ConferenceTracker;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午4:55
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTrackerTest {
    ConferenceTracker conferenceTracker;
    Rule rule;
    List talks = new ArrayList();

    @Before
    public void setup() {
        conferenceTracker = new ConferenceTracker();
        talks.add("talk1 30minutes");
        rule = new Rule().startNoEarlyThan("0900");

    }
    @Test
    public void shouldBeInitiated() {
        ConferenceTracker tracker = new ConferenceTracker();
        assertNotNull(tracker);
    }

    @Test
    public void shouldNotMakeNullPlan() {
        List plan = conferenceTracker.makePlan(talks, rule) ;
        assertNotNull(plan);
    }

    @Test
    public void shouldPlanNotBefore9AM() {
        List plan = conferenceTracker.makePlan(talks, rule);
        ConferenceTalk talk = (ConferenceTalk)plan.get(0);
        assertEquals("0900", talk.getStartTime());
        assertEquals("0930", talk.getEndTime());
    }



}
