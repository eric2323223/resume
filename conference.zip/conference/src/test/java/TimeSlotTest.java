import org.junit.Test;

import peng.tdd.ct.Timeslot;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:50
 * To change this template use File | Settings | File Templates.
 */
public class TimeSlotTest {

    @Test
    public void test1() {
        assertEquals("1000", Timeslot.getEndTime("0900", "60"));
    }

    @Test
    public void test2() {
        assertEquals("1010", Timeslot.getEndTime("0930", "40"));
    }

    @Test
    public void test3() {
        assertEquals("1200", Timeslot.getEndTime("1030", "90"));
    }
}
