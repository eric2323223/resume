import org.junit.Test;
import peng.tdd.ct.ProposedTalk;
import peng.tdd.ct.Timeslot;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:50
 * To change this template use File | Settings | File Templates.
 */
public class TimeSlotTest {
    Timeslot timeslot;

//    @Test
//    public void shouldCalculateEndTime() {
//        assertEquals("1005", Timeslot.getEndTime("1000", "5"));
//        assertEquals("1000", Timeslot.getEndTime("0900", "60"));
//        assertEquals("1010", Timeslot.getEndTime("0930", "40"));
//        assertEquals("1200", Timeslot.getEndTime("1030", "90"));
//        assertEquals("1505", Timeslot.getEndTime("1445", "20"));
//    }

    @Test
    public void testConstructor1() {
        timeslot = new Timeslot(9, 0, 90, "talk");
        assertEquals(9, timeslot.getStartHour());
        assertEquals(10, timeslot.getEndHour());
        assertEquals(30, timeslot.getEndMinute());
        assertEquals("talk", timeslot.getTalkName());
    }

    @Test
    public void testConstructor2() {
        timeslot = new Timeslot(9, 0, 10, 15, "talk");
        assertEquals(9, timeslot.getStartHour());
        assertEquals(0, timeslot.getStartMinute());
        assertEquals(75, timeslot.getLength());
        assertEquals(10, timeslot.getEndHour());
        assertEquals(15, timeslot.getEndMinute());
        assertEquals("talk", timeslot.getTalkName());
    }

    @Test
    public void testToString() {
        timeslot = new Timeslot(9, 0, 75, "talk");
        assertEquals("09:00AM talk 75min", timeslot.toString());
        timeslot = new Timeslot(14, 0, 120, "talk2");
        assertEquals("02:00PM talk2 120min", timeslot.toString());
    }

    @Test
    public void testFit() {
        timeslot = new Timeslot(9, 0, 20, null);
        List<ProposedTalk> talks = new ArrayList<ProposedTalk>();
        talks.add(new ProposedTalk("talk1 30min"));
        talks.add(new ProposedTalk("talk2 45min"));
        talks.add(new ProposedTalk("talk3 5min"));
        talks.add(new ProposedTalk("talk4 15min"));

        List<ProposedTalk> planedtalks = timeslot.fit(talks);
        assertEquals(2, planedtalks.size());
        assertEquals("talk3", planedtalks.get(0).getName());
        assertEquals("talk4", planedtalks.get(1).getName());
    }


}
