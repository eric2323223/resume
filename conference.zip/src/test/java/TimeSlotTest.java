import org.junit.Test;
import peng.tdd.ct.Timeslot;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-20
 * Time: 下午7:50
 * To change this template use File | Settings | File Templates.
 */
public class TimeSlotTest {
    Timeslot timeslot;

    @Test
    public void testConstructor1() {
        timeslot = new Timeslot(9, 0, 90, "talk");
        assertEquals(9, timeslot.getStartHour());
        assertEquals(10, timeslot.getEndHour());
        assertEquals(30, timeslot.getEndMinute());
        assertEquals("talk", timeslot.getTalkName());
    }

    @Test
    public void testConstructor2() {
        timeslot = new Timeslot(9, 0, 10, 15, "talk");
        assertEquals(9, timeslot.getStartHour());
        assertEquals(0, timeslot.getStartMinute());
        assertEquals(75, timeslot.getLength());
        assertEquals(10, timeslot.getEndHour());
        assertEquals(15, timeslot.getEndMinute());
        assertEquals("talk", timeslot.getTalkName());
    }

    @Test
    public void testToString() {
        timeslot = new Timeslot(9, 0, 75, "talk");
        assertEquals("09:00AM talk 75min", timeslot.toString());
        timeslot = new Timeslot(14, 0, 120, "talk2");
        assertEquals("02:00PM talk2 120min", timeslot.toString());
    }

    @Test
    public void testSubstract() {
        timeslot = new Timeslot(9, 0, 12, 0);
        Timeslot slot2 = new Timeslot(9, 0, 30, null);
        Timeslot result = timeslot.substract(slot2);
        assertEquals(9, result.getStartHour());
        assertEquals(30, result.getStartMinute());
        assertEquals(12, result.getEndHour());
        assertEquals(0, result.getEndMinute());
        assertEquals(150, result.getLength());
    }

    @Test
    public void testSubstract2() {
        timeslot = new Timeslot(13, 0, 18, 0);
        Timeslot slot2 = new Timeslot(17, 0, 18, 0);
        Timeslot result = timeslot.substract(slot2);
        assertEquals(13, result.getStartHour());
        assertEquals(0, result.getStartMinute());
        assertEquals(17, result.getEndHour());
        assertEquals(0, result.getEndMinute());
    }
}
