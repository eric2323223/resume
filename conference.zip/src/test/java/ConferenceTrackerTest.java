import org.junit.Before;
import org.junit.Test;
import peng.tdd.ct.ConferenceTracker;
import peng.tdd.ct.ProposedTalk;
import peng.tdd.ct.Timeslot;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Created with IntelliJ IDEA.
 * User: think
 * Date: 17-8-19
 * Time: 下午4:55
 * To change this template use File | Settings | File Templates.
 */
public class ConferenceTrackerTest {
    ConferenceTracker conferenceTracker;
    List<ProposedTalk> talks = new ArrayList<ProposedTalk>();

    @Before
    public void setup() {
        conferenceTracker = new ConferenceTracker();
        List<Timeslot> slots = new ArrayList<Timeslot>();
        slots.add(new Timeslot(9, 0, 12, 0));
        slots.add(new Timeslot(13, 0, 18, 0));
        conferenceTracker.setAvailableTimeSlots(slots);

    }
    @Test
    public void shouldBeInitiated() {
        ConferenceTracker tracker = new ConferenceTracker();
        assertNotNull(tracker);
    }

    @Test
    public void shouldNotMakeNullPlan() {
        List plan = conferenceTracker.makePlan(talks) ;
        assertNotNull(plan);
    }

    @Test
    public void shouldPlanNotBefore9AM() {
        talks.add(new ProposedTalk("talk1 30min"));
        List<Timeslot> plan = conferenceTracker.makePlan(talks);
        Timeslot talk = plan.get(0);
        assertEquals(9, talk.getStartHour());
        assertEquals(0, talk.getStartMinute());
        assertEquals(9, talk.getEndHour());
        assertEquals(30, talk.getEndMinute());
    }

    @Test
    public void shouldPlanMultipleTalks() {
        talks.add(new ProposedTalk("talk1 30min"));
        talks.add(new ProposedTalk("talk2 45min"));
        List<Timeslot> plan = conferenceTracker.makePlan(talks);
        assertEquals(2, plan.size());
        Timeslot talk1 = plan.get(0);
        assertEquals(9, talk1.getStartHour());
        assertEquals(0, talk1.getStartMinute());
        assertEquals(9, talk1.getEndHour());
        assertEquals(30, talk1.getEndMinute());
        Timeslot talk2 = plan.get(1);
        assertEquals(9, talk2.getStartHour());
        assertEquals(30, talk2.getStartMinute());
        assertEquals(10, talk2.getEndHour());
        assertEquals(15, talk2.getEndMinute());
    }

    @Test
    public void shouldMakeEfficientPlan() {
        talks.add(new ProposedTalk("talk1 150min"));
        talks.add(new ProposedTalk("talk2 90min"));
        talks.add(new ProposedTalk("talk3 150min"));
        talks.add(new ProposedTalk("talk4 30min"));
        talks.add(new ProposedTalk("talk5 60min"));
        List<Timeslot> plan = conferenceTracker.makePlan(talks);
        assertEquals(5, plan.size());
        assertEquals("09:00AM talk1 150min", plan.get(0).toString());
        assertEquals("11:30AM talk4 30min", plan.get(1).toString());
        assertEquals("01:00PM talk2 90min", plan.get(2).toString());
        assertEquals("02:30PM talk3 150min", plan.get(3).toString());
        assertEquals("05:00PM talk5 60min", plan.get(4).toString());
    }

    @Test
    public void shouldFitAsMuchAsTalks() {
        talks.add(new ProposedTalk("talk1 120min"));
        talks.add(new ProposedTalk("talk2 30min"));
        talks.add(new ProposedTalk("talk3 240min"));
        talks.add(new ProposedTalk("talk4 15min"));
        talks.add(new ProposedTalk("talk5 30min"));
        talks.add(new ProposedTalk("talk6 45min"));
        List<Timeslot> plan = conferenceTracker.makePlan(talks);
        assertEquals(6, plan.size());
    }

    @Test
    public void shouldFitAsMuchAsTalksWithNetworkEvent() {
        conferenceTracker.setNetworkEventSlot(new Timeslot(17,0, 60, "Network Event"));
        talks.add(new ProposedTalk("talk1 120min"));
        talks.add(new ProposedTalk("talk2 30min"));
        talks.add(new ProposedTalk("talk3 210min"));
        talks.add(new ProposedTalk("talk4 15min"));
        talks.add(new ProposedTalk("talk5 30min"));

        List<Timeslot> plan = conferenceTracker.makePlan(talks);
        assertEquals(6, plan.size());
        assertEquals("09:00AM talk1 120min", plan.get(0).toString());
        assertEquals("11:00AM talk2 30min", plan.get(1).toString());
        assertEquals("11:30AM talk5 30min", plan.get(2).toString());
        assertEquals("01:00PM talk3 210min", plan.get(3).toString());
        assertEquals("04:30PM talk4 15min", plan.get(4).toString());
        assertEquals("05:00PM Network Event ", plan.get(5).toString());
    }

    @Test
    public void shouldPrintPlan() throws IOException {
        Writer writer = mock(Writer.class);
        talks.add(new ProposedTalk("talk1 30min"));
        talks.add(new ProposedTalk("talk2 30min"));
        talks.add(new ProposedTalk("yet another talk lightning"));
        conferenceTracker.makePlan(talks);
        conferenceTracker.printPlan(writer);
        verify(writer).write("09:00AM talk1 30min\n" +
                            "09:30AM talk2 30min\n" +
                            "10:00AM yet another talk lightning\n");
        verify(writer).close();
    }

    @Test
    public void shouldPrintPlanWithNetWorkEvent() throws IOException {
        conferenceTracker.setNetworkEventSlot(new Timeslot(17, 0, 60, "Network Event"));
        Writer writer = mock(Writer.class);
        talks.add(new ProposedTalk("talk1 30min"));
        talks.add(new ProposedTalk("talk2 30min"));
        talks.add(new ProposedTalk("yet another talk lightning"));
        conferenceTracker.makePlan(talks);
        conferenceTracker.printPlan(writer);
        verify(writer).write("09:00AM talk1 30min\n" +
                "09:30AM talk2 30min\n" +
                "10:00AM yet another talk lightning\n" +
                "05:00PM Network Event \n");
        verify(writer).close();
    }


}
